"""Compare mixture and estimated phase with the same MP-SENet magnitude."""
import argparse
from functools import partial
import json
from pathlib import Path
import sys

import librosa
import numpy as np
import pandas as pd
import torch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.project.resolve()
    upstream = root / "external/MP-SENet"
    sys.path[:0] = [str(root), str(upstream)]
    from env import AttrDict
    from dataset import mag_pha_stft, mag_pha_istft
    from models.model import MPNet
    from src.audio_utils import load_audio
    from src.metrics import evaluate_signal

    torch.set_num_threads(2)
    checkpoint = upstream / "best_ckpt/g_best_vb"
    config = AttrDict(json.loads(checkpoint.with_name("config.json").read_text()))
    network = MPNet(config).eval()
    for layer in network.modules():
        if isinstance(layer, torch.nn.MultiheadAttention):
            layer.forward = partial(layer.forward, need_weights=False)
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    network.load_state_dict(state["generator"])
    transform = (config.n_fft, config.hop_size, config.win_size, config.compress_factor)
    archive = root / "results/mpsenet"
    matched = pd.read_csv(archive / "mpsenet_metrics.csv")
    assert len(matched) == matched.Enhanced_File.nunique() == 167
    args.output.mkdir(parents=True, exist_ok=True)
    output = args.output / "pairs.csv"
    pending = output.with_suffix(".tmp")
    rows = []
    with torch.inference_mode():
        for row in matched.itertuples(index=False):
            waveform, _ = librosa.load(
                archive / "input_noisy" / row.Enhanced_File, sr=config.sampling_rate
            )
            mixture = torch.from_numpy(waveform)
            normalisation = torch.sqrt(len(mixture) / mixture.square().sum())
            amplitude, phase, _ = mag_pha_stft((mixture * normalisation).unsqueeze(0), *transform)
            estimate, estimated_phase, _ = network(amplitude, phase)
            clean, _ = load_audio(root / "data/clean" / row.Clean_File, target_sr=config.sampling_rate)
            result = dict(File=row.Enhanced_File, Clean=row.Clean_File,
                          Noise=row.Noise_Type, SNR=row.Target_SNR_dB)
            for label, angle in [("mix", phase), ("model", estimated_phase)]:
                synthesis = mag_pha_istft(estimate, angle, *transform)
                enhanced = (synthesis / normalisation).squeeze().numpy()
                length = min(len(enhanced), len(clean))
                scores = evaluate_signal(clean[:length], enhanced[:length], config.sampling_rate)
                result.update({f"{label}_{metric}": score for metric, score in scores.items()})
                result[f"{label}_peak"] = float(np.abs(enhanced).max())
            originals = {"STOI": row.STOI, "PESQ": row.PESQ, "SI-SDR": row.SI_SDR_dB}
            for metric, original in originals.items():
                result[f"delta_{metric}"] = result[f"model_{metric}"] - result[f"mix_{metric}"]
                result[f"archive_diff_{metric}"] = result[f"model_{metric}"] - original
            assert np.isfinite(list(result.values())[4:]).all(), row.Enhanced_File
            rows.append(result)
            pd.DataFrame(rows).to_csv(pending, index=False)
            pending.replace(output)
            print(len(rows), row.Enhanced_File, flush=True)


if __name__ == "__main__":
    main()
