"""Summarize paired inference results by original utterance and test condition."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

directory = Path(sys.argv[1])
pairs = pd.read_csv(directory / "pairs.csv")
assert len(pairs) == pairs.File.nunique() == 167
assert pairs.Clean.nunique() == 27
metrics = ["STOI", "PESQ", "SI-SDR"]
delta_columns = [f"delta_{metric}" for metric in metrics]
gains = pairs.groupby("Clean")[delta_columns]
counts = gains.size().to_numpy()
sums = gains.sum().to_numpy()
draws = np.random.default_rng(5305).integers(len(counts), size=(10000, len(counts)))
boot_means = sums[draws].sum(axis=1) / counts[draws].sum(axis=1)[:, None]
lower, upper = np.quantile(boot_means, [0.025, 0.975], axis=0)

records = []
for index, metric in enumerate(metrics):
    delta = pairs[f"delta_{metric}"]
    mix = pairs[f"mix_{metric}"]
    model = pairs[f"model_{metric}"]
    np.testing.assert_allclose(delta, model - mix, rtol=0, atol=1e-12)
    archive_error = pairs[f"archive_diff_{metric}"].abs()
    records.append({
        "metric": metric, "mix": mix.mean(), "model": model.mean(),
        "delta": delta.mean(), "low": lower[index], "high": upper[index],
        "wins": int((delta > 0).sum()), "losses": int((delta < 0).sum()),
        "ties": int((delta == 0).sum()), "archive_mae": archive_error.mean(),
        "archive_max": archive_error.max(),
    })
summary = pd.DataFrame(records)
summary.to_csv(directory / "summary.csv", index=False)
groups = pairs.groupby(["Noise", "SNR"])[delta_columns]
cells = groups.mean().assign(N=groups.size())
cells.to_csv(directory / "by_condition.csv")
print(summary.to_string(index=False))
print(cells.to_string())
print(pairs[["mix_peak", "model_peak"]].max())
