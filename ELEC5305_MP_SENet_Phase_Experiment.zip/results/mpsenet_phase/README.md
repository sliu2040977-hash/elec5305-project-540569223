# MP-SENet phase ablation

The 167 input filenames match the historical MP-SENet score archive. Run with
the original input WAVs, clean references, and VoiceBank checkpoint described
in the repository's data instructions.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 python experiments/mpsenet_phase_ablation.py . results/mpsenet_phase
python experiments/summarize_mpsenet_phase.py results/mpsenet_phase
```

The code scores both float reconstructions at 16 kHz. The same model-estimated
magnitude is used in each pair. Gains are model phase minus mixture phase.
The archived model scores came from PCM16 output. The paired CSV includes the
difference from those scores. The summary uses 10,000 utterance-level
bootstrap resamples with seed 5305.
